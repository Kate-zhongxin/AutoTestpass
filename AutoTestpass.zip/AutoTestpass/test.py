# coding: utf-8

if __name__ == '__main__':
    pass
    # case_dict = {}
    #
    # for c in _WorkSheet.iter_rows():
    #     if c[0].value is not None and c[0].value.lower() == "DP0106002".lower():
    #         print c[2].value



