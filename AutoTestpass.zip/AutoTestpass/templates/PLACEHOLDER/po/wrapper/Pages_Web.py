class Pages_Web:
    def __init__(self, UI):
        self._UI = UI