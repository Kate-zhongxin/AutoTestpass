class CaseDesInfo:
    def __init__(self):
        self.id = None
        self.title = []
        self.description = []
        self.expectedResult = []

    COL_ID = 1
    COL_TITLE = 2
    COL_DESCRIPTION = 3
    COL_EXPECTED_RESULT = 4
